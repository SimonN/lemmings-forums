[center]
[size=4][color=red]ATTENTION[/color][/size]
[hr]Uninstalling "PM Attachments" will uninstall the mod but will *NOT* remove the "pm_attachments" folder (or any of the files in it) from your main SMF Root directory.
If you have associated other directories with this mod they will also be retained.

When you uninstall this mod you may choose to keep or delete all the data that has been stored in the database for this mod.
If you select the option to delete the data members will NO longer be able to download PM attachments they have already received.

[b]DO NOT remove the database data unless you are also going to manually remove the "pm_attachments" folder (and the files in it) from your main SMF Root directory.[/b]

Thank You for trying this MOD :)[/center]